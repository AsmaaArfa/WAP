const express = require('express');
const router = express.Router();
const ContactMe = require('../models/ContactMeModel.jsx');
const username = require('../server.js')

// Create or Update Contact Me
router.post('/api/contact', async (req, res) => {
    const { gmail, linkedIn } = req.body;
    try {
        const contact = await ContactMe.findOneAndUpdate(
            {},
            { gmail, linkedIn, username },
            { upsert: true, new: true }
        );
        res.json(contact);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Read Contact Me
router.get('/api/contact', async (req, res) => {
    try {
        const contact = await ContactMe.findOne({username: username});
        res.json(contact);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Update Contact Me
router.put('/api/contact/:id', async (req, res) => {
    const { gmail, linkedIn } = req.body;
    try {
        const contact = await ContactMe.findByIdAndUpdate(
            {username: req.params.id},
            { gmail, linkedIn },
            { new: true }
        );
        res.json(contact);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

// Delete Contact Me
router.delete('/api/contact/:id', async (req, res) => {
    try {
        await ContactMe.findByIdAndDelete(req.params.id);
        res.json({ message: 'Contact Me section deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
});

module.exports = router;